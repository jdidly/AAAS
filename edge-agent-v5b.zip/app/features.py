import pandas as pd, numpy as np

def ta_rsi(series, period=14):
    delta = series.diff()
    gain = (delta.where(delta>0,0)).rolling(period).mean()
    loss = (-delta.where(delta<0,0)).rolling(period).mean()
    rs = gain/(loss+1e-9)
    return 100 - (100/(1+rs))

def add_features(df, horizon=10):
    out = df.copy()
    close = out['close']
    out['ret1'] = close.pct_change(1)
    out['ret5'] = close.pct_change(5)
    out['rsi14'] = ta_rsi(close,14)
    out['ema20'] = close.ewm(span=20).mean()
    out['ema50'] = close.ewm(span=50).mean()
    out['ema200'] = close.ewm(span=200).mean()
    out['y_future'] = (close.shift(-horizon) > close).astype(int)
    return out.dropna()
