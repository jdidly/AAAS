import ccxt, pandas as pd, time
from . import config

def make_exchange():
    ex = ccxt.binanceus({"enableRateLimit": True})
    ex.load_markets()
    return ex

def fetch_ohlcv(exchange, symbol, timeframe='1m', days=30, limit=1000):
    ms_per_day = 24*60*60*1000
    since = exchange.milliseconds() - days*ms_per_day
    all_rows, cursor = [], since
    while True:
        batch = exchange.fetch_ohlcv(symbol, timeframe=timeframe, since=cursor, limit=limit)
        if not batch: break
        all_rows.extend(batch)
        last_ts = batch[-1][0]
        cursor = last_ts + 1
        if last_ts >= exchange.milliseconds() - 120000: break
        time.sleep(exchange.rateLimit/1000)
        if len(all_rows) >= days*1440: break
    df = pd.DataFrame(all_rows, columns=['ts','open','high','low','close','volume'])
    df['datetime'] = pd.to_datetime(df['ts'], unit='ms', utc=True)
    df.set_index('datetime', inplace=True)
    return df.astype(float)
