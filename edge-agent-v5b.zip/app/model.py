import lightgbm as lgb, joblib, numpy as np, os
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, roc_auc_score
from . import config

FEATURES = ['ret1','ret5','rsi14','ema20','ema50','ema200']

def train_model(df_feat, symbol):
    X = df_feat[FEATURES]; y = df_feat['y_future']
    X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2,shuffle=False)
    model = lgb.LGBMClassifier(n_estimators=200,learning_rate=0.05)
    model.fit(X_train,y_train)
    acc = accuracy_score(y_test, model.predict(X_test))
    auc = roc_auc_score(y_test, model.predict_proba(X_test)[:,1])
    path = os.path.join(config.MODEL_DIR, f"{symbol.replace('/','_')}.pkl")
    joblib.dump(model,path)
    return {'acc':acc,'auc':auc,'path':path}

def load_model(symbol):
    path = os.path.join(config.MODEL_DIR, f"{symbol.replace('/','_')}.pkl")
    return joblib.load(path)

def predict(df_feat, symbol):
    model = load_model(symbol)
    X = df_feat[FEATURES].iloc[[-1]]
    p_up = float(model.predict_proba(X)[0,1])
    return {'symbol':symbol,'p_up':p_up,'direction':'LONG' if p_up>=0.5 else 'SHORT'}
