from fastapi import FastAPI
from . import service

app = FastAPI()

@app.get('/health')
def health():
    return {'status':'ok'}

@app.post('/train')
def train():
    return service.train()

@app.post('/predict')
def predict():
    return service.predict()
