import os, pandas as pd
from datetime import datetime
from . import fetch, features, model, config

def train():
    ex = fetch.make_exchange()
    results = []
    for sym in config.SYMBOLS:
        df = fetch.fetch_ohlcv(ex,sym,days=config.DAYS_HISTORY)
        df_feat = features.add_features(df, horizon=config.HORIZON_MIN)
        res = model.train_model(df_feat, sym)
        results.append({'symbol':sym,**res})
    return {'trained':results}

def predict():
    ex = fetch.make_exchange()
    preds = []
    for sym in config.SYMBOLS:
        df = fetch.fetch_ohlcv(ex,sym,days=1)
        df_feat = features.add_features(df, horizon=config.HORIZON_MIN)
        res = model.predict(df_feat,sym)
        res['timestamp'] = datetime.utcnow().isoformat()
        preds.append(res)
    # log
    os.makedirs(config.OUTPUT_DIR,exist_ok=True)
    logpath = os.path.join(config.OUTPUT_DIR,'predictions.csv')
    pd.DataFrame(preds).to_csv(logpath,mode='a',header=not os.path.exists(logpath),index=False)
    return {'predictions':preds}
